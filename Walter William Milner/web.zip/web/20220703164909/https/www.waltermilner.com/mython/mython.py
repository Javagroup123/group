# coding: utf-8
"""Mython

Some code to support fundamental maths ideas in Python, using finite sets.

As far as possible items are named for what they are. For example, the class 
defining a set is named Set. As consequence, only a few docstrings are needed.

Inheritance is not always used. For example a natural number is a set, but we do
not make NaturalNumber extend Set, because there is little point.

We define natural numbers, integers and rationals in terms of sets. But we also use
Python ints where it seems simpler.  

"""


class Set:


	def __init__(self, arg1, arg2=None, arg3=None):
		""" The set can be defined with a given list, or as a
		formula to calulate the nth term, and a range. A name is optional.
		Examples:
		A = Set([1, 2, 3, 2, 1], "A") gets name 'A'. Duplicates ignored
		A = Set([1, 2, 3]) set name is the stringified list
		A = Set(range(1, 100), "3*n") multiples of 3 from 3 to 300
		A = Set(range(1, 10), "1/n") 1, 0.5, 0.333, 0.25..0.1


		"""
		if isinstance(arg1, list):
			# need to avoid duplicates
			self.elements = []
			for _v in arg1:
				if _v not in self.elements:
					self.elements.append(_v)
			if arg2 == None:
				n = "( "
				for e in arg1:
					n += str(e) + " "
				n += " )"
				self.name = n
			else:
				self.name = arg2

		else:
			self.elements = []
			for n in arg1:
				_v = eval(arg2)
				self.elements.append(_v)
			if arg3 == None:
				self.name = str(arg2)
			else:
				self.name = arg3

	def hasMember(self, y):
		""" Is y an element of this set """
		return y in self.elements

	def __eq__(self, other):
		for _x in self.elements:
			if _x not in other.elements:
				return False
		for _x in other.elements:
			if _x not in self.elements:
				return False
		return True

	def union(self, other):
		_v = self.elements
		for _x in other.elements:
			if _x not in _v:
				_v.append(_x)
		return Set(_v, str(self) + " ∪ " + str(other))

	def intersection(self, other):
		_v = []
		for _x in self.elements:
			if _x in other.elements:
				_v.append(_x)
		return Set(_v, str(self) + " ∩ " + str(other))

	def difference(self, other):
		_v = []
		for _x in self.elements:
			if _x not in other.elements:
				_v.append(_x)
		return Set(_v, str(self) + " - " + str(other))

	def symDiff(self, other):
		""" symmetric difference """
		_v = []
		for _x in self.elements:
			if _x not in other.elements:
				_v.append(_x)
		for _x in other.elements:
			if _x not in self.elements:
				_v.append(_x)
		return Set(_v, str(self) + " Δ " + str(other	))

	def isSubset(self, other):
		for _x in self.elements:
			if _x not in other.elements:
				return False
		return True

	def card(self):
		""" Cardinality """
		return len(self.elements)

	def powerSet(self):
		n = len(self.elements)  # count of elements

		overall = []  # will be collection of all subsets
		for pattern in range(0, 2**n):  # basis for each subset
			# produce string of bits, pattern in base 2, padded with
			# leading 0 for a width of n bits:
			fString = "0" + str(n) + "b"
			bitString = format(pattern, fString)
			thisList = []  # for this subset..
			for index in range(0, len(bitString)):
				c = bitString[index]
				if c == "1":  # add element if bit is 1
					thisList.append(self.elements[index])
			ss = Set(thisList)  # make subset from list
			overall.append(ss)  # add subset to collection

		return Set(overall)  # make Set from collection

	def cartesianProduct(self, other):
		pairs = []
		for el1 in self.elements:
			for el2 in other.elements:
				pairs.append([el1, el2])
		return Set(pairs)

	def __str__(self):
		return self.name

	def getElements(self):
		s = "Elements of " + self.name + ": \n"
		for el in self.elements:
			s += str(el) + "\n"

		return s




class Relation(Set):
	

	def __init__(self, domain, codomain, arg3, name):

		self.domain = domain
		self.codomain = codomain
		if isinstance(arg3, list):
			self.elements = []
			for pair in arg3:
				if pair[0] not in domain.elements:
					raise TypeError("Relation error : not in domain " + str(pair[0]))
				if pair[1] not in codomain.elements:
					raise TypeError("Relation error : not in codomain " + str(pair[1]))
				self.elements.append(pair)
		else:
			raise TypeError(str(arg3) +" should be a list of map pairs.")

		self.name = "Relation " + str(name)

	def image(self):
		""" Also known as range """
		result = []
		for pair in self.elements:
			result.append(pair[1])
		return Set(result)

	def isReflexive(self):
		for x in self.domain.elements:
			if [x, x] not in self.elements:
				return False
		return True

	def isSymmetric(self):
		for p in self.elements:
			op = [p[1], p[0]]
			if op not in self.elements:
				return False
		return True

	def isAntiSymmetric(self):
		for p in self.elements:
			x = p[0]
			y = p[1]
			if [y, x] in self.elements and not x == y:
				return False
		return True

	def isTransitive(self):
		for p in self.elements:
			for q in self.elements:
				if p[1] == q[0]:
					if [p[0], q[1]] not in self.elements:
						return False
		return True

	def isEquivalence(self):
		return self.isReflexive() and self.isSymmetric() and self.isTransitive()

	def isOrder(self):
		return self.isReflexive() and self.isAntiSymmetric() and self.isTransitive()


class Function(Relation):
	def __init__(self, domain, codomain, pairs, name):

		self.domain = domain
		self.codomain = codomain
		if not isinstance(pairs, list):
			raise TypeError("Function error : not a list " + str(pairs))
		for pair in pairs:
			x = pair[0]
			y = pair[1]
			for others in pairs:
				if others[0] == x:
					if others[1] != y:
						raise TypeError("Function error :" + str(x) + " maps to 2 values")

		self.elements = pairs
		self.name = "Function " + str(name)

	def isInjective(self):
		for pair in self.elements:
			x = pair[0]
			y = pair[1]
			for others in self.elements:
				if others[1] == y and others[0] != x:
					return False
		return True

	def isSurjective(self):
		return self.codomain.equals(self.range())


class Rational:
	""" A rational number class """

	def __init__(self, a, b):
		# check integers
		if not isinstance(a, int):
			raise TypeError("Making rational : need integer, got " + str(a))
		if not isinstance(b, int):
			raise TypeError("Making rational : need integer, got " + str(b))
		if b == 0:
			raise TypeError("Making rational : got 0 denominator ")

		if b < 0:  # make numerator -ve
			a = -a
			b = -b
		self.pair = (a, b)

	def __add__(self, other):
		a = self.pair[0]
		b = self.pair[1]
		c = other.pair[0]
		d = other.pair[1]
		return Rational(a * d + c * b, b * d)

	def __mul__(self, other):
		a = self.pair[0]
		b = self.pair[1]
		c = other.pair[0]
		d = other.pair[1]
		return Rational(a * c, b * d)

	def __sub__(self, other):
		a = self.pair[0]
		b = self.pair[1]
		c = other.pair[0]
		d = other.pair[1]
		return Rational(a * d - c * b, b * d)

	def __truediv__(self, other):
		a = self.pair[0]
		b = self.pair[1]
		c = other.pair[0]
		d = other.pair[1]
		return Rational(c * d, a * b)

	def __eq__(self, other):
		a = self.pair[0]
		b = self.pair[1]
		c = other.pair[0]
		d = other.pair[1]
		# reduce to lowest form
		f = gcd(a, b)
		a = a / f
		b = b / f
		f = gcd(c, d)
		c = c / f
		d = d / f

		return a == c and b == d

	def __str__(self):
		return str(self.pair[0]) + "/" + str(self.pair[1])


class Z:
	""" A signed integer type """

	def __init__(self, a, b):
		# check integers
		if not isinstance(a, int):
			raise TypeError("Making z : need integer, got " + str(a))
		if not isinstance(b, int):
			raise TypeError("Making z : need integer, got " + str(b))

		self.pair = (a, b)  # Python tuple

	def __add__(self, other):
		a = self.pair[0]
		b = self.pair[1]
		c = other.pair[0]
		d = other.pair[1]
		return Z(a + c, b + d)

	def __mul__(self, other):
		a = self.pair[0]
		b = self.pair[1]
		c = other.pair[0]
		d = other.pair[1]
		return Z(a * c + b * d, a * d + b * c)

	def __sub__(self, other):
		a = self.pair[0]
		b = self.pair[1]
		c = other.pair[0]
		d = other.pair[1]
		return Z(a - c, b - d)

	def __eq__(self, other):
		a = self.pair[0]
		b = self.pair[1]
		c = other.pair[0]
		d = other.pair[1]
		return (a - b) == (c - d)

	def __str__(self):
		return str(self.pair[0]) + "," + str(self.pair[1]) + " = " + str(self.pair[0] - self.pair[1])

class BinaryOp(Function):
	""" A binary operation """
	def __init__(self, domain, values):
		""" values should be a list of triples [x,y,z] such that 
		x•y = z """
		# check arguments
		if not isinstance(domain, Set):
			raise TypeError(str(domain) + "should be a Set")
		if not isinstance(values, list):
			raise TypeError(str(values) + "should be a list")
		for t in values:
			if t[0] not in domain.elements or t[1] not in domain.elements or t[2] not in domain.elements:
				raise Exception(str(t)+ " value not in domain")		

		self.domain=domain
		self.values=values
	
	def apply(self, x,y):
		""" return x◦y"""
		for triple in self.values:
			if x==triple[0] and y==triple[1]:
				return triple[2]
		raise TypeError("Binary operation - no value for " + str(x)+" and "+str(y))

	def identity(self):
		""" Returns left identity, or None""" 
		for x in self.domain.elements:
			ok=True
			for y in self.domain.elements:
				if self.apply(x,y)!=y:
					ok=False
			if ok:
				return x
		return None		





	def inverse(self,x):
		i=self.identity()
		if i==None:
			raise Exception("Finding inverse, but there is no identity " + str(x))
		for y in self.domain.elements:
			if self.apply(x,y)==i:
				return y

	def allHaveInverse(self):
		""" Return true iff all elements have inverses"""
		i=self.identity()
		if i==None:
			raise Exception("Finding inverses, but there is no identity ")
		for x in self.domain.elements:
			if self.inverse(x)==None:
				return False
		return True

	def isAssoc(self):
		""" Return true iff this is associative """
		for x in self.domain.elements:
			for y in self.domain.elements:
				for z in self.domain.elements:
					a=self.apply(self.apply(x,y),z)
					b=self.apply(x, self.apply(y,z))
					if not a==b:
						return False
		return True				


	def __str__(self):
		result=""
		for t in self.values:
			result+=str(t[0])+" • "+str(t[1])+" = "+str(t[2])+"\n"
		return result		

class Group(BinaryOp):
	def __init__(self, domain, values):
		""" values should be a list of triples [x,y,z] such that 
		x•y = z """
		# check arguments
		if not isinstance(domain, Set):
			raise TypeError(str(domain) + "should be a Set")
		if not isinstance(values, list):
			raise TypeError(str(values) + "should be a list")
		for t in values:
			if t[0] not in domain.elements or t[1] not in domain.elements or t[2] not in domain.elements:
				raise Exception(str(t)+ " value not in domain")		
		self.domain=domain
		self.values=values
		if self.identity()==None:
			raise Exception("Not a group - no identity")
		if self.allHaveInverse()==False:
			raise Exception("Not a group - not all elements have inverses")
		if self.isAssoc()==False:
			raise Exception("Not a group - not associative")		








	



# Utilities


def gcd(a, b):	
	if b < 0:
		b = -b
	while not b == 0:
		t = b
		b = a % b
		a = t
	return a


nullSet = Set([], "Null set")


class NaturalNumber:
	def __init__(self, n):
		self.name = "Zermelo " + str(n)
		if n == 0:
			self.elements = []
		else:
			self.elements = [NaturalNumber(n - 1).elements]

	def succ(self):
		s = NaturalNumber(0)
		s.elements = [self.elements]
		s.name = "Zermelo succ( " + self.name + " )"
		return s

	def pred(self):
		if len(self.elements) == 0:
			raise TypeError("Zero has no predecessor ")
		else:
			s = NaturalNumber(0)
			s.elements = self.elements[0]
			s.name = "Zermelo pred( " + self.name + " )"
			return s

	def __add__(self, other):
		if len(other.elements) == 0:
			return self
		else:
			return self.succ().__add__(other.pred())


# -- your code starts here -------------------------------------


A = Set([0,1,2])
t=[[x,y,z] for x in A.elements for y in A.elements for z in A.elements if z == (x+y) % 3 ]
b=Group(A, t)
print(b.isAssoc()) # True


